package com.FinalExam.ClbManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClbManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClbManagementApplication.class, args);
	}

}
